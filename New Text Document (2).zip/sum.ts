function sumAll(...num:string[]){
let concating:string;
for(var a of num){
concating=concating+a;
console.log("sum inside loop is : "+concating);
}
console.log("sum outside loop is : "+concating);
}

sumAll("subham","agarwal,"is"," testing");