var Dummy = /** @class */ (function () {
    function Dummy() {
    }
    return Dummy;
}());
var b;
constructor();
{
    for (b = 0; b < 5; b++) {
        console.log(b);
    }
    console.log("last value of b is :" + b);
}
new Dummy();
