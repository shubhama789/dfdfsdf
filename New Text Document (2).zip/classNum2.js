"use strict";
exports.__esModule = true;
var ClassNum1_1 = require("./ClassNum1");
var abc1 = new ClassNum1_1.ClassNum1();
console.log(abc1.a);
abc1.m1();
