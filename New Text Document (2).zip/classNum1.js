"use strict";
exports.__esModule = true;
var ClassNum1 = /** @class */ (function () {
    function ClassNum1() {
    }
    ClassNum1.prototype.m1 = function () {
        console.log('hi');
    };
    return ClassNum1;
}());
exports.ClassNum1 = ClassNum1;
