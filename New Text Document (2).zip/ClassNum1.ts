export class ClassNum1{
a:number;
b:number;
public m1(){
	console.log('hi');
}
constructor(){}
}