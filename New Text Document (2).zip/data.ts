interface Employee{

firstName:string;
lastName:string;
age:number;
salary:number;
check:boolean;

}
let employee:Employee={
firstName:'123',
lastName:"agarwal",
age:21,
salary:5000,
check:true
}
console.log("name is "+employee.firstName+" "+employee.lastName+"\n age is "+employee.age+"\n salary is "+employee.salary+"\n condition is "+employee.check)