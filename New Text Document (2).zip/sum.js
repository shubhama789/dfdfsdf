function sumAll() {
    var num = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        num[_i] = arguments[_i];
    }
    var concating;
    for (var _a = 0, num_1 = num; _a < num_1.length; _a++) {
        var a = num_1[_a];
        concating = concating + a;
        console.log("sum inside loop is : " + concating);
    }
    console.log("sum outside loop is : " + concating);
}
sumAll("subham", "agarwal,", is, ",", testing, "););
