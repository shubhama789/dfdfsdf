var employee = {
    firstName: '123',
    lastName: "agarwal",
    age: 21,
    salary: 5000,
    check: true
};
console.log("name is " + employee.firstName + " " + employee.lastName + "\n age is " + employee.age + "\n salary is " + employee.salary + "\n condition is " + employee.check);
