var dummy = "subham";
var dumdum = "hi this is " + dummy + "  and i am writing a code and characters in my name is " + dummy.length;
console.log(dumdum);
