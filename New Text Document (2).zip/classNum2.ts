import {ClassNum1} from './ClassNum1'

let abc1 = new ClassNum1();
console.log(abc1.a);
abc1.m1();