import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  //template: `<h1>Helo, this is me exploring</h1><br><h1>welcome Friend</h1>`,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  styles:[`.def{background-color: yellow;}`]
})
export class AppComponent  { 
  title='myApp';
  mycolor='aqua';
  name = 'Subham Kumar Agarwal';
  dumb ='hello';
myStyle={
  'background-color':"pink",
  'padding': "10px",
  'height': "auto"
}
inputBox1={
  'background-color':"deepskyblue",
  'color':"red"
}
inputBox2={
  'background-color':"lawngreen"
}
changeText(){
  this.dumb= this.dumb==='hello'? 'clicked':this.dumb==='clicked Again'?'hello':'clicked Again';
 
}

}
